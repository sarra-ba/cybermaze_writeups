const canvas = document.getElementById('game-canvas');
const ctx = canvas.getContext('2d');
const scoreElement = document.getElementById('score');
const highScoreElement = document.getElementById('high-score');
const finalScoreElement = document.getElementById('final-score');
const gameOverElement = document.getElementById('game-over');
const startScreenElement = document.getElementById('start-screen');
const restartBtn = document.getElementById('restart-btn');

const GRAVITY = 0.6;
const JUMP_FORCE = -13;
const GROUND_Y = 200;
const TREX_WIDTH = 44;
const TREX_HEIGHT = 47;
const OBSTACLE_WIDTH = 25;
const OBSTACLE_MIN_HEIGHT = 40;
const OBSTACLE_MAX_HEIGHT = 60;
let OBSTACLE_SPEED = 7;
const SPEED_INCREASE = 0.001;

let trex = {
    x: 80,
    y: GROUND_Y - TREX_HEIGHT,
    vy: 0,
    width: TREX_WIDTH,
    height: TREX_HEIGHT,
    jumping: false,
    legFrame: 0,
    frameCount: 0
};

let obstacles = [];
let clouds = [];
let score = 0;
let highScore = localStorage.getItem('highScore') || 0;
let gameRunning = false;
let gameStarted = false;
let frameCount = 0;

// User session
let currentUser = JSON.parse(localStorage.getItem('currentUser')) || null;
let scoreSubmitCount = 0;

function drawTrex() {
    ctx.fillStyle = '#535353';
    
    // Body
    ctx.fillRect(trex.x + 6, trex.y + 10, 25, 25);
    
    // Head
    ctx.fillRect(trex.x + 25, trex.y, 15, 12);
    
    // Eye
    ctx.fillStyle = '#fff';
    ctx.fillRect(trex.x + 32, trex.y + 2, 4, 4);
    ctx.fillStyle = '#535353';
    
    // Mouth
    ctx.fillRect(trex.x + 38, trex.y + 6, 2, 4);
    
    // Tail
    ctx.fillRect(trex.x, trex.y + 15, 10, 6);
    
    // Arms
    ctx.fillRect(trex.x + 20, trex.y + 15, 8, 3);
    
    // Legs animation (running)
    if (!trex.jumping) {
        if (Math.floor(trex.frameCount / 5) % 2 === 0) {
            // Left leg
            ctx.fillRect(trex.x + 10, trex.y + 35, 6, 12);
            // Right leg
            ctx.fillRect(trex.x + 20, trex.y + 35, 6, 10);
        } else {
            // Left leg
            ctx.fillRect(trex.x + 10, trex.y + 35, 6, 10);
            // Right leg
            ctx.fillRect(trex.x + 20, trex.y + 35, 6, 12);
        }
        trex.frameCount++;
    } else {
        // Static legs when jumping
        ctx.fillRect(trex.x + 10, trex.y + 35, 6, 12);
        ctx.fillRect(trex.x + 20, trex.y + 35, 6, 12);
    }
}

function drawGround() {
    ctx.fillStyle = '#535353';
    ctx.fillRect(0, GROUND_Y, canvas.width, 3);
    
    // Ground pattern
    for (let i = 0; i < canvas.width; i += 20) {
        ctx.fillRect(i, GROUND_Y + 5, 2, 2);
    }
}

function drawClouds() {
    clouds.forEach(cloud => {
        ctx.fillStyle = 'rgba(180, 180, 180, 0.5)';
        ctx.fillRect(cloud.x, cloud.y, 30, 10);
        ctx.fillRect(cloud.x + 10, cloud.y - 5, 25, 10);
        ctx.fillRect(cloud.x + 20, cloud.y, 20, 10);
    });
}

function updateClouds() {
    if (Math.random() < 0.005) {
        clouds.push({
            x: canvas.width,
            y: Math.random() * 60 + 20
        });
    }
    
    clouds.forEach((cloud, index) => {
        cloud.x -= 1;
        if (cloud.x + 50 < 0) {
            clouds.splice(index, 1);
        }
    });
}

function drawObstacle(obstacle) {
    ctx.fillStyle = '#535353';
    
    if (obstacle.type === 'cactus') {
        // Main cactus body
        ctx.fillRect(obstacle.x + 5, obstacle.y, 15, obstacle.height);
        
        // Arms
        ctx.fillRect(obstacle.x, obstacle.y + 10, 5, 8);
        ctx.fillRect(obstacle.x + 20, obstacle.y + 15, 5, 8);
        
        // Spikes
        for (let i = 0; i < obstacle.height; i += 8) {
            ctx.fillRect(obstacle.x + 3, obstacle.y + i, 2, 3);
            ctx.fillRect(obstacle.x + 20, obstacle.y + i, 2, 3);
        }
    } else if (obstacle.type === 'bird') {
        // Bird body
        ctx.fillRect(obstacle.x + 5, obstacle.y + 5, 15, 10);
        
        // Wings (animated)
        const wingOffset = Math.floor(frameCount / 5) % 2 === 0 ? 0 : -3;
        ctx.fillRect(obstacle.x, obstacle.y + 5 + wingOffset, 10, 5);
        ctx.fillRect(obstacle.x + 15, obstacle.y + 5 + wingOffset, 10, 5);
        
        // Beak
        ctx.fillRect(obstacle.x + 20, obstacle.y + 8, 5, 4);
    }
}

function updateTrex() {
    trex.vy += GRAVITY;
    trex.y += trex.vy;

    if (trex.y >= GROUND_Y - TREX_HEIGHT) {
        trex.y = GROUND_Y - TREX_HEIGHT;
        trex.vy = 0;
        trex.jumping = false;
    }
}

function updateObstacles() {
    if (frameCount % 90 === 0 && Math.random() < 0.8) {
        const obstacleType = Math.random() < 0.7 ? 'cactus' : 'bird';
        const obstacleHeight = obstacleType === 'cactus' 
            ? OBSTACLE_MIN_HEIGHT + Math.random() * (OBSTACLE_MAX_HEIGHT - OBSTACLE_MIN_HEIGHT)
            : 20;
        const yPosition = obstacleType === 'cactus' 
            ? GROUND_Y - obstacleHeight
            : GROUND_Y - 60 - Math.random() * 20;
            
        obstacles.push({
            x: canvas.width,
            y: yPosition,
            width: OBSTACLE_WIDTH,
            height: obstacleHeight,
            type: obstacleType
        });
    }

    obstacles.forEach((obstacle, index) => {
        obstacle.x -= OBSTACLE_SPEED;

        if (obstacle.x + obstacle.width < 0) {
            obstacles.splice(index, 1);
            score++;
        }
    });
    
    // Gradually increase speed
    OBSTACLE_SPEED += SPEED_INCREASE;
}

function checkCollision() {
    obstacles.forEach(obstacle => {
        if (
            trex.x < obstacle.x + obstacle.width &&
            trex.x + trex.width > obstacle.x &&
            trex.y < obstacle.y + obstacle.height &&
            trex.y + trex.height > obstacle.y
        ) {
            gameRunning = false;
        }
    });
}

function draw() {
    // Sky gradient
    const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
    gradient.addColorStop(0, '#87CEEB');
    gradient.addColorStop(0.7, '#f0f0f0');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    drawClouds();
    drawGround();
    drawTrex();
    obstacles.forEach(drawObstacle);
}

function update() {
    if (gameStarted) {
        updateTrex();
        updateObstacles();
        updateClouds();
        checkCollision();
        frameCount++;
        
        // Update score display with leading zeros
        scoreElement.textContent = String(score).padStart(6, '0');
        highScoreElement.textContent = 'HI: ' + String(highScore).padStart(6, '0');
    }
}

function gameLoop() {
    if (gameRunning) {
        update();
        draw();
        requestAnimationFrame(gameLoop);
    } else if (gameStarted) {
        finalScoreElement.textContent = `Score: ${score}`;
        if (score > highScore) {
            highScore = score;
            localStorage.setItem('highScore', highScore);
        }
        
        // Submit score to server if user is logged in
        if (currentUser) {
            submitScore(score);
        }
        
        gameOverElement.style.display = 'block';
    }
}

// Submit score to server
async function submitScore(playerScore) {
    if (!currentUser) {
        console.log('Not logged in - score not submitted');
        return;
    }
    
    try {
        const response = await fetch('/api/submit_score', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: currentUser.user_id,
                score: playerScore
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            console.log('Score submitted successfully!');
            console.log('Total score:', data.total_score);
            if (data.hint) {
                console.log('%c' + data.hint, 'color: #ffd700; font-size: 14px;');
            }
            scoreSubmitCount++;
        } else {
            console.log('Score submission failed:', data.message);
        }
    } catch (error) {
        console.error('Error submitting score:', error);
    }
}

// Login function
async function login(username, password) {
    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (data.success) {
            currentUser = {
                user_id: data.user_id,
                username: data.username
            };
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            console.log('%cLogin successful! Welcome ' + data.username, 'color: #00ff00; font-size: 16px;');
            return true;
        } else {
            console.log('%cLogin failed: ' + data.message, 'color: #ff0000; font-size: 14px;');
            if (data.error) {
                console.log('Error details:', data.error);
            }
            return false;
        }
    } catch (error) {
        console.error('Login error:', error);
        return false;
    }
}

// Get leaderboard
async function getLeaderboard() {
    try {
        const response = await fetch('/api/leaderboard');
        const data = await response.json();
        
        console.table(data.leaderboard);
        return data.leaderboard;
    } catch (error) {
        console.error('Error fetching leaderboard:', error);
    }
}

// Search users
async function searchUser(username) {
    try {
        const response = await fetch(`/api/search?username=${encodeURIComponent(username)}`);
        const data = await response.json();
        
        if (data.success) {
            console.table(data.users);
            return data.users;
        } else {
            console.log('Search error:', data.message);
            if (data.error) {
                console.log('Error details:', data.error);
            }
        }
    } catch (error) {
        console.error('Search error:', error);
    }
}



function jump() {
    if (!trex.jumping && gameStarted) {
        trex.vy = JUMP_FORCE;
        trex.jumping = true;
    }
}

function startGame() {
    if (!gameStarted) {
        gameStarted = true;
        gameRunning = true;
        startScreenElement.style.display = 'none';
        gameLoop();
    } else if (gameRunning) {
        jump();
    }
}

function restart() {
    trex.y = GROUND_Y - TREX_HEIGHT;
    trex.vy = 0;
    trex.jumping = false;
    trex.frameCount = 0;
    obstacles = [];
    clouds = [];
    score = 0;
    frameCount = 0;
    OBSTACLE_SPEED = 7;
    gameRunning = true;
    gameOverElement.style.display = 'none';
    gameLoop();
}

document.addEventListener('keydown', (e) => {
    if (e.code === 'Space') {
        e.preventDefault();
        startGame();
    }
});

canvas.addEventListener('click', () => {
    startGame();
});

restartBtn.addEventListener('click', restart);

// Expose functions for CTF
window.login = login;
window.getLeaderboard = getLeaderboard;
window.searchUser = searchUser;


if (currentUser) {
    console.log(`%c✓ Logged in as: ${currentUser.username}`, 'color: #00ff00;');
    updateUserInfo();
}

// Update user info display
function updateUserInfo() {
    const userInfoElement = document.getElementById('user-info');
    if (userInfoElement) {
        if (currentUser) {
            userInfoElement.textContent = `👤 ${currentUser.username}`;
        } else {
            userInfoElement.textContent = '👤 Guest (not logged in)';
        }
    }
}

// Initialize display
highScoreElement.textContent = 'HI: ' + String(highScore).padStart(6, '0');
updateUserInfo();
draw();