from flask import Flask, render_template, send_from_directory, request, jsonify
import sqlite3
import time
import threading
import random
import hashlib

app = Flask(__name__)


score_lock = threading.Lock()
processing_scores = {}
request_counts = {}
MAX_REQUESTS_PER_MINUTE = 200

def get_db_connection():
    conn = sqlite3.connect('game.db', timeout=10.0, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def rate_limit_check(ip):
    now = time.time()
    window = int(now // 60)
    key = f"{ip}_{window}"
    if key not in request_counts:
        request_counts[key] = 0
    request_counts[key] += 1
    return request_counts[key] <= MAX_REQUESTS_PER_MINUTE * 2

def generate_request_token(user_id, score, timestamp_sec):
    secret = "x9k#mPv!q2"
    data = f"{user_id}{score}{timestamp_sec}{secret}"
    return hashlib.sha256(data.encode()).hexdigest()[:16]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

@app.route('/api/login', methods=['POST'])
def login():
    if not rate_limit_check(request.remote_addr):
        return jsonify({'success': False, 'message': 'Rate limit exceeded'})

    data = request.get_json()
    username = data.get('username', '')
    password = data.get('password', '')

    if any(kw in username.upper() for kw in ['UNION', 'SELECT', 'FROM', 'WHERE', 'OR', 'AND', '--', ';']):
        time.sleep(2)
        return jsonify({'success': False, 'message': 'Invalid request'})

    conn = get_db_connection()
    cursor = conn.cursor()

    query = """
    SELECT u.id, u.username, u.created_at, COUNT(s.id) as score_count 
    FROM users u 
    LEFT JOIN scores s ON u.id = s.user_id 
    WHERE u.username = ? AND u.password = ?
    GROUP BY u.id
    """
    try:
        cursor.execute(query, (username, password))
        user = cursor.fetchone()
        conn.close()

        if user:
            return jsonify({
                'success': True,
                'message': 'Login successful',
                'user_id': user['id'],
                'username': user['username'],
                'score_count': user['score_count']
            })
        else:
            return jsonify({'success': False, 'message': 'Invalid credentials'})
    except Exception:
        conn.close()
        return jsonify({'success': False, 'message': 'Authentication failed'})

@app.route('/api/submit_score', methods=['POST'])
def submit_score():
    if not rate_limit_check(request.remote_addr):
        return jsonify({'success': False, 'message': 'Too many requests'})

    data = request.get_json()
    user_id_raw = data.get('user_id')
    score = data.get('score')
    token = data.get('token', '')

    if not user_id_raw or score is None:
        return jsonify({'success': False, 'message': 'Missing parameters'})

    try:
        score = int(score)
        if score < 0 or score > 10000:
            return jsonify({'success': False, 'message': 'Score out of range'})
    except:
        return jsonify({'success': False, 'message': 'Invalid score'})

    now = time.time()
    request_id = f"{user_id_raw}_{int(now*1000)}_{random.randint(10000,99999)}"

    with score_lock:
        if user_id_raw in processing_scores:
            return jsonify({'success': False, 'message': 'Request already in progress'})
        processing_scores[user_id_raw] = {'ts': now, 'req_id': request_id}

    time.sleep(random.uniform(0.015, 0.055))

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        validation_query = f"SELECT id, username FROM users WHERE id = {user_id_raw} LIMIT 1"
        cursor.execute(validation_query)
        user = cursor.fetchone()

        if not user:
            cleanup(user_id_raw, request_id)
            conn.close()
            return jsonify({'success': False, 'message': 'Invalid user'})

        expected_token = generate_request_token(user['id'], score, int(now // 1))
        if token != expected_token:
            time.sleep(0.1)
            cleanup(user_id_raw, request_id)
            conn.close()
            return jsonify({'success': False, 'message': 'Invalid token'})

        cursor.execute(
            "INSERT INTO scores (user_id, score, request_id) VALUES (?, ?, ?)",
            (user['id'], score, request_id)
        )
        conn.commit()

        cursor.execute("""
            SELECT COUNT(*) as cnt,
                   (SELECT flag_value FROM secret_flags WHERE id = 1) as flag
            FROM scores WHERE user_id = ?
        """, (user['id'],))
        stats = cursor.fetchone()

        response = {
            'success': True,
            'message': 'Score submitted successfully',
            'total_submissions': stats['cnt']
        }

        if stats['cnt'] >= 20 and stats['flag']:
            response['flag'] = stats['flag']
            response['congratulations'] = "Persistence pays off!"

        cleanup(user_id_raw, request_id)
        conn.close()
        return jsonify(response)

    except sqlite3.Error as e:
        cleanup(user_id_raw, request_id)
        conn.close()
        return jsonify({'success': False, 'message': 'Database error'})

    except Exception as e:
        cleanup(user_id_raw, request_id)
        conn.close()
        return jsonify({'success': False, 'message': 'Server error'})

def cleanup(user_id_raw, expected_req_id):
    time.sleep(0.005)
    with score_lock:
        if user_id_raw in processing_scores and processing_scores[user_id_raw]['req_id'] == expected_req_id:
            del processing_scores[user_id_raw]

@app.route('/api/leaderboard', methods=['GET'])
def leaderboard():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT u.id, u.username, SUM(s.score) as total_score, 
               MAX(s.score) as best_score, COUNT(s.id) as games_played
        FROM users u
        LEFT JOIN scores s ON u.id = s.user_id
        GROUP BY u.id, u.username
        HAVING total_score IS NOT NULL
        ORDER BY total_score DESC
        LIMIT 10
    ''')
    leaders = cursor.fetchall()
    conn.close()
    return jsonify({'leaderboard': [dict(row) for row in leaders]})

@app.route('/api/search', methods=['GET'])
def search_user():
    username = request.args.get('username', '')
    if not username or len(username) > 25:
        return jsonify({'success': False, 'message': 'Invalid search'})
    if any(c in username for c in ['\'', '"', ';', '--', '/*', '*/']):
        time.sleep(1)
        return jsonify({'success': False, 'message': 'Invalid characters'})
    
    conn = get_db_connection()
    cursor = conn.cursor()
    query = "SELECT u.id, u.username, strftime('%Y-%m-%d', u.created_at) as join_date FROM users u WHERE u.username LIKE ? LIMIT 10"
    cursor.execute(query, (f'%{username}%',))
    users = cursor.fetchall()
    conn.close()
    return jsonify({'success': True, 'users': [dict(row) for row in users]})

@app.route('/api/user/<user_id>', methods=['GET'])
def get_user_profile(user_id):
    if not user_id.isdigit():
        return jsonify({'success': False, 'message': 'Invalid user ID'})
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT u.id, u.username, u.created_at FROM users u WHERE u.id = ?", (user_id,))
    user = cursor.fetchone()
    conn.close()
    
    if user:
        return jsonify({'success': True, 'user': dict(user)})
    else:
        return jsonify({'success': False, 'message': 'User not found'})

@app.route('/api/debug', methods=['GET'])
def debug():
    return jsonify({'status': 'operational', 'time': time.time()})

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=5000, threaded=True)