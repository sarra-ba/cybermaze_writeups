import sqlite3
import os

def init_database():
    db_path = 'game.db'
    
    if os.path.exists(db_path):
        os.remove(db_path)
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_score_submit TIMESTAMP,
            total_submissions INTEGER DEFAULT 0
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS scores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            score INTEGER NOT NULL,
            submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            request_id TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS secret_flags (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            flag_name TEXT NOT NULL,
            flag_value TEXT NOT NULL,
            description TEXT
        )
    ''')
    
    sample_users = [
        ('fakeuser', 'fakepass'),
    ]
    
    cursor.executemany('INSERT INTO users (username, password) VALUES (?, ?)', sample_users)
    
    flag_value = os.getenv('FLAG', 'CM{flag}')
    print(f"[+] Using flag: {flag_value}")
    
    cursor.execute('''
        INSERT INTO secret_flags (flag_name, flag_value, description) 
        VALUES (?, ?, ?)
    ''', ('flag', flag_value, 'Main CTF flag '))
    
    sample_scores = [
        (1, 1530),
    ]
    
    cursor.executemany('INSERT INTO scores (user_id, score) VALUES (?, ?)', sample_scores)
    
    conn.commit()
    conn.close()
    
    print("Database initialized successfully!")

if __name__ == '__main__':
    init_database()